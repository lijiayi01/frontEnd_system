var dataModule = function(){

    var  data = [];

    return data;

}()
